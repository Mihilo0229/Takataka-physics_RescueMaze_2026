
/*******************************************************************************************/
/* Yaw・Pitch・Roll角の取得                                                                            
/*処理：MPU6050を用いて回転や坂検知のためのRoll・Yaw角の取得
/*
/*更新者：清田侑希　2025/1/25
/*更新者:阿部実裕 202/01/25 デバックモードの実装
/*******************************************************************************************/
void getYawPitchRoll() {
  #if DEBUGMODE
    Serial.println(".----getYawPitchRoll() Started----.");
  #endif
  MPU.update();   // ★ 毎回必ず呼ぶ

  yaw   = MPU.getYaw360();    // 0〜360
  pitch = MPU.getPitch();  // deg
  roll  = MPU.getRoll();   // deg
  #if DEBUGMODE
    Serial.print("Yaw : ");
    Serial.print(yaw);
    Serial.print(" Pitch: ");
    Serial.print(pitch);
    Serial.print(" Roll: ");
    Serial.print(roll);
    Serial.println(" ----by getYawPitchRoll()");
    Serial.println("`----getYawPitchRoll() Finished----`");
  #endif
}

/*******************************************************************************************/
/* 地磁気２                                                                              
/*処理：坂の検知に用いるRoll角の整数化
/*変更点：MPU6050の設置方向の関係からPitch角からRoll角に仕様変更
/*更新者：清田侑希 2025/1/25
/*更新者:阿部実裕ー令和六年度入学　2026/01/25 変更点:デバックモードの実装
/*******************************************************************************************/
void tiziki_2(){
  #if DEBUGMODE
    Serial.println(".----tiziki_2() Started----.");
  #endif
  getYawPitchRoll();
  katamuki = roll;
  katamuki_true = int(katamuki);
  #if DEBUGMODE
    Serial.print("katamuki_true: ");
    Serial.println(katamuki_true);
    Serial.println(" ----by tiziki_2()");
    Serial.println("`----tiziki_2() Finished----`"); 
  #endif
}


/*******************************************************************************************/
/* collect_tof_data                                                                              
/*処理： ヘッダーが来たら6バイト距離のデータを取得するこれによって各壁の検知を行う
/*
/*更新者：清田侑希　2025/1/26
/*清田侑希　2025/2/23 変更点：壁の有無を各方向の2つのセンサーがともに壁を検知したときのみ壁とみなす
/*清田侑希　2025/3/30 変更点：tofセンサーをの値を生のデータのまま送信する
/*阿部実裕ー令和六年度入学　2026/01/25 変更点：デバックモード実装
/*******************************************************************************************/
void get_tof_data() {
  #if DEBUGMODE
    Serial.println(".----get_tof_data() Started----.");
  #endif
  // ===== ToF 要請 + 応答 =====
  bool ok = tofUART.request(CMD_TOF, tof_buf, 200);  //@@@tyousei@@@
  // ↑ timeout は 120〜150ms 推奨（後述）

  if (!ok) {
    now_wall.rightW = false;
    now_wall.forwardW = false;
    now_wall.leftW = false;
    Status = 0;
    #if DEBUGMODE
      Serial.println("!----get_tof_data() Stopped due to TOF timeout----!");
    #endif
    return;
  }

  // ===== データ確定 =====
  for (int i = 0; i < 6; i++) {
    receivedData[i] = tof_buf[i];
  }

  #if DEBUGMODE
    Serial.print("TOF: ");
    for (int i = 0; i < 6; i++) {
      Serial.print(receivedData[i]);
      if (i < 5) Serial.print(", ");
    }
    Serial.println(" ----by get_tof_data()");
  #endif

  // ===== 壁判定 =====
  now_wall.forwardW = (receivedData[0] <= isItWall && receivedData[3] <= isItWall);
  now_wall.leftW  = (receivedData[1] <= isItWall && receivedData[2] <= isItWall);
  now_wall.rightW = (receivedData[4] <= isItWall && receivedData[5] <= isItWall);

  Status = 1;
  #if DEBUGMODE
    Serial.println("`----get_tof_data() Finished----`");
  #endif
}




/*******************************************************************************************/
/*色タイルまたはバンプ                                                                              
/*処理：Serial1にデータが来たら1バイト読み込んで青、黒、ロードセルを検知する
/*Data 1:黒タイル　2：青タイル　3：左の障害物　4：右の障害物　5：前の壁　6：銀のタイル
/*更新者：清田侑希　2025/1/26
/*清田侑希　2025/2/23 変更点：障害物を検知して最初の動作の時に壁との距離を測るようにした
/*清田侑希　2025/3/28 変更点：障害物を検知したとき毎回壁との距離を測るようにした
/*阿部実裕　2026/01/26 変更点：デバックモード実装
/*******************************************************************************************/
bool initialized = false;
void s1() {
  #if DEBUGMODE
    Serial.println(".----s1() Started----.");
  #endif
  /* ======================================
      初回呼び出し時だけの初期化
      ====================================== */
  if (!initialized) {
    #if DEBUGMODE
      Serial.println("<----initialized by s1()---->");
    #endif
    while (Serial4.available() > 0) {
        Serial4.read();
    }
    initialized = true;
  }
  /* ======================================
      イベントがなければ何もしない
      ====================================== */
  if (!colorUART.hasEvent()) {
    #if DEBUGMODE
      Serial.println("!----s1() Stopped deu to No Event----!");
    #endif
    return;
  }

  /* ======================================
      ヘッダ待ち
      ====================================== */
  byte header = colorUART.readEvent();
  if (header != 0xAA) {
    #if DEBUGMODE
      Serial.println("!----s1() Stopped deu to No Header----!");
    #endif
    return;   // ヘッダじゃなければ破棄
  }

  /* ======================================
      ここから「3バイト揃うまで待つ」
      ====================================== */
  unsigned long start = millis();
  while (Serial4.available() < 2) {
    if (millis() - start > 5) {//@@@tyousei@@@
        // 5ms 以内に揃わなければ諦める
        #if DEBUGMODE
          Serial.println("!----s1() Stopped deu to Not Ready for 3-byte in 5-ms----!");
        #endif
        return;
    }
  }

  uint8_t receivedData2 = colorUART.readEvent();
  uint8_t check         = colorUART.readEvent();

  /* ======================================
      チェックサム確認
      ====================================== */
  if ((receivedData2 ^ 0xFF) != check) {
    #if DEBUGMODE
      Serial.println("!----s1() Stopped deu to UART EVENT Checksum Error----!");
    #endif
    return;
  }

  #if DEBUGMODE
    Serial.println("<----s1() Proceeded to Correct Communication without any Error---->");
    Serial.print("UART EVENT = ");Serial.print(receivedData2);Serial.println("----by s1()");
  #endif

  /* ======================================
      イベント処理（1イベント）
      ====================================== */
  switch (receivedData2) {
    case 1:  // BLACK TILE
      #if DEBUGMODE
        Serial.println("<----Black Tile was Detected by s1()---->");
      #endif
      BlackTile = true;
      while (count2 > -2) {
        drive.forward(-303);
        delay(100);
        count2--;
      }
      drive.stop();
      count2 = 40;

      break;

    case 2:  // BLUE TILE
      #if DEBUGMODE
        Serial.println("<----Blue Tile was Detected by s1()---->");
      #endif
      blue_count = true;
      break;

    case 5:  // forward BUMP
      #if DEBUGMODE
        Serial.println("<----forward Bump was Detected by s1()---->");
      #endif
      drive.stop();
      delay(500);
      drive.forward(-2025);
      delay(1000);
      drive.stop();
      if (count2 < 20 && bump_giveup_count > 1) {
        Gap = true;
      }
      count2 = 40;
      break;

    case 3:  // LEFT
      #if DEBUGMODE
        Serial.println("<----Left by s1()---->");
      #endif
      drive.stop(); delay(500);
      drive.turnLeft(1023); delay(500); delay(500);
      drive.forward(-1240); delay(700); delay(500);
      drive.turnRight(1534); delay(700); delay(500);
      now_wall.forwardW = false;
      get_tof_data();
      if (receivedData[0] <= 90 && receivedData[3] <= 90 && abs(receivedData[0] - receivedData[3]) < 30) {
        if(count2 < 20) Gap = true; count2 = 46; 
      } 
      count2 -= 6;
      bump_giveup_count++;
      test++;      
    break;

    case 4:
      #if DEBUGMODE
        Serial.println("<----Right by s1()---->");
      #endif
      drive.stop(); delay(500);
      drive.turnRight(1023); delay(500); delay(500);
      drive.forward(-1240); delay(700); delay(500);
      drive.turnLeft(1534); delay(700); delay(500);
      now_wall.forwardW = false;
      get_tof_data();
      if (receivedData[0] <= 90 && receivedData[3] <= 90 && abs(receivedData[0] - receivedData[3]) < 30) {
        if(count2 < 20) Gap = true; count2 = 46; 
      } 
      count2 -= 6;
      bump_giveup_count++;
      test++;
      break;

    case 6:  // CHECK POINT
      #if DEBUGMODE
        Serial.println("<----Check Point was Detected by s1()---->");
      #endif
      checkPoint = now;
      NeoPixel1_On(255,255,255);
      delay(200);
      NeoPixel1_Off();
      break;

    default:
      #if DEBUGMODE
        Serial.println("<----Unkown Event by s1()---->");
      #endif
      break;
  }
  #if DEBUGMODE
    Serial.println("`----s1() Finished----`");
  #endif
}

/* ======================================
   s1 初期化リセット
   ====================================== */
void s1_reset() {
  #if DEBUGMODE
    Serial.println("<----s1 initialized by s1_reset()---->");
  #endif
  initialized = false;
}
