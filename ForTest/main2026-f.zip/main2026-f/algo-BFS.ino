
int BFS_whichWay(NodeD here){
  if(here.x + 1 < maxX//エリア内
     && cost[here.x+1][here.y] == cost[here.x][here.y]-1//コストが一つ低い方へ
     && !(Maps[here.x][here.y] & wallD.E)) return East;//壁が無かったら
  else if(here.y + 1 < maxY
     && cost[here.x][here.y+1] == cost[here.x][here.y]-1
     && !(Maps[here.x][here.y] & wallD.N)) return North;
  else if(here.x - 1 >= 0
     && cost[here.x-1][here.y] == cost[here.x][here.y]-1
     && !(Maps[here.x][here.y] & wallD.W)) return West;
  else if(here.y - 1 >= 0
     && cost[here.x][here.y-1] == cost[here.x][here.y]-1
     && !(Maps[here.x][here.y] & wallD.S)) return South;

  else return Err;
}

void BFS_makeMap(){
  while(!Map_Q.empty()){
    NodeD check = Map_Q.front();
    Map_Q.pop();

    //Serial.print(check.x);Serial.println(check.y);

    if(check.x + 1 < maxX
       && cost[check.x+1][check.y] == -1
       && !(Maps[check.x][check.y] & wallD.E)){
          cost[check.x+1][check.y] = cost[check.x][check.y] + 1;
          Map_Q.push({check.x+1,check.y});
    //      Serial.print("E");
    }
    if(check.y + 1 < maxY 
       && cost[check.x][check.y+1] == -1 
       && !(Maps[check.x][check.y] & wallD.N)){
          cost[check.x][check.y+1] = cost[check.x][check.y] + 1;
          Map_Q.push({check.x,check.y+1});
    //      Serial.print("N");
    }
    if(check.x - 1 >= 0 
       && cost[check.x-1][check.y] == -1 
       && !(Maps[check.x][check.y] & wallD.W)){
          cost[check.x-1][check.y] = cost[check.x][check.y] + 1;
          Map_Q.push({check.x-1,check.y});
    //      Serial.print("W");
    }
    if(check.y - 1 >= 0 
       && cost[check.x][check.y-1] == -1 
       && !(Maps[check.x][check.y] & wallD.S)){
          cost[check.x][check.y-1] = cost[check.x][check.y] + 1;
          Map_Q.push({check.x,check.y-1});
    //      Serial.print("S");
    }
    //Serial.println();
  }
  //Serial.println();
  //Serial.println("end mapping");
  //Serial.println();

}

void BFS_wayHome(NodeD now){
  NodeD goal = {50,50,North};

  while (!(now.x == goal.x && now.y == goal.y)){//現在地がゴールじゃなかったら、
    int next = BFS_whichWay(now);//絶対方向で生きたい方向を取得
    if(next == Err){
      Serial.print("Err Err Err");
      break;
    }

    if(clearD(next - now.dir) == 0){//差分で行きたい方向を定める
      way_q.push(forwerd);//前進
      switch(now.dir){//座標更新
        case North:
          now = {now.x,now.y+1,clearD(now.dir +0)};
    //      Serial.print(now.x);Serial.println(now.y);
          break;
        case East:
          now = {now.x+1,now.y,clearD(now.dir +0)};
    //      Serial.print(now.x);Serial.println(now.y);
          break;
        case South:
          now = {now.x,now.y-1,clearD(now.dir +0)};
    //      Serial.print(now.x);Serial.println(now.y);
          break;
        case West:
          now = {now.x-1,now.y,clearD(now.dir +0)};
    //      Serial.print(now.x);Serial.println(now.y);
          break;
        default:
          now = {0,0,North};
      }
    }
    else if(clearD(next - now.dir) == 1){
      way_q.push(left);//左折
      way_q.push(forwerd);//前進
      switch(now.dir){
        case North:
          now = {now.x+1,now.y,clearD(now.dir +1)};
    //      Serial.print(now.x);Serial.println(now.y);
          break;
        case East:
          now = {now.x,now.y-1,clearD(now.dir +1)};
    //      Serial.print(now.x);Serial.println(now.y);
          break;
        case South:
          now = {now.x-1,now.y,clearD(now.dir +1)};
    //      Serial.print(now.x);Serial.println(now.y);
          break;
        case West:
          now = {now.x,now.y+1,clearD(now.dir +1)};
    //      Serial.print(now.x);Serial.println(now.y);
          break;
        default:
          now = {0,0,North};
      }
    }
    else if(clearD(next - now.dir) == 2){
      way_q.push(right);//右折
      way_q.push(right);//２回かけて後ろ向きに（つまり、左折でもOK）
      way_q.push(forwerd);//前進
      switch(now.dir){
        case North:
          now = {now.x,now.y-1,clearD(now.dir +2)};
    //      Serial.print(now.x);Serial.println(now.y);
          break;
        case East:
          now = {now.x-1,now.y,clearD(now.dir +2)};
    //      Serial.print(now.x);Serial.println(now.y);
          break;
        case South:
          now = {now.x,now.y+1,clearD(now.dir +2)};
    //      Serial.print(now.x);Serial.println(now.y);
          break;
        case West:
          now = {now.x+1,now.y,clearD(now.dir +2)};
    //      Serial.print(now.x);Serial.println(now.y);
          break;
        default:
          now = {0,0,North};
      }
    }
    else if(clearD(next - now.dir) == 3){
      way_q.push(right);//右折
      way_q.push(forwerd);//前進
      switch(now.dir){
        case North:
          now = {now.x-1,now.y,clearD(now.dir +3)};
    //      Serial.print(now.x);Serial.println(now.y);//Nw
          break;
        case East:
          now = {now.x,now.y+1,clearD(now.dir +3)};
    //      Serial.print(now.x);Serial.println(now.y);//En
          break;
        case South:
          now = {now.x+1,now.y,clearD(now.dir +3)};
    //      Serial.print(now.x);Serial.println(now.y);//Se
          break;
        case West:
          now = {now.x,now.y-1,clearD(now.dir +3)};
    //      Serial.print(now.x);Serial.println(now.y);//Ws
          break;
        default:
          now = {0,0,North};
      }
    }
  }
  //Serial.println(clearD(goal.dir-now.dir));
  if(!(clearD(goal.dir-now.dir) == 2)){//方向を調整
    switch(clearD(goal.dir-now.dir)){
      
      case 1:
        way_q.push(right);//右折
        break;
      case 0:
        way_q.push(right);//反転
        way_q.push(right);
        break;
      case 3:
        way_q.push(left);//左折
        break;
    }
  }
}
