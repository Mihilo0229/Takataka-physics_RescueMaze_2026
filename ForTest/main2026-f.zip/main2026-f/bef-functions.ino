

/** ----------spin()---------- @internal
 * @brief 指定角度に指定速度で超信地旋回する関数
 * @param {int} vto 回転して向かう角度。負が左、正が右。+180で回れ右。0も可能。
 * @param {int} vspeed 回転速度。省略推奨。デフォルトは440。
 * @endinternal
 * =====使用ライブラリ=====
 * arduino
 * time
 * MyBasicDrive
 * MyYPRs
 * =====以下変更履歴=====
 * 2026/01/25ーmigi()とひだり()に代わって制作 by.阿部実裕ー令和六年度入学
 */
void spin(int vto, int vspeed = 440)
{
  Serial.print(".----spin() Started to ");Serial.print(vto);Serial.print("° by Speed ");Serial.println(vspeed);Serial.println("----.");
  getYawPitchRoll();
  MPU.resetYaw();
  delay(50);

  if(vto == 0){
    #if DEBUGMODE
      Serial.println("!----spin() Stopped deu to vto is 0----!");
    #endif
  }
  else if(vto < 0){
    while(MPU.getYaw360() < vto || MPU.getYaw360() > 345){
      drive.turnRight(vspeed);
      delay(100);
      MPU.update();
      #if DEBUGMODE
        Serial.print("Yaw: ");Serial.print(MPU.getYaw360());Serial.println(" ----by spin()");
      #endif
      delay(50);
    }
  }
  else{
    while (MPU.getYaw360() > vto || MPU.getYaw360() < 15) {
      drive.turnLeft(vspeed);
      delay(100);
      MPU.update();
      #if DEBUGMODE 
        Serial.print("Yaw: ");Serial.print(MPU.getYaw360());Serial.println(" ----by spin()");
      #endif
        delay(50);
    }
  }
  Serial.println("`----spin() Finished----`");
}

#if 1
/*右回転                                                                              
*処理：MPU6050で取得したデータをもとに90度右回転するまでモーターを回し続ける
*変更点：ギア搭載による回転方向の反転と適切なdelayの実装
*更新者：清田侑希　2025/1/25
*　清田侑希　2025/3/12 変更点：90度モーターのみで回転し、90度回らなかったら補正を行う
*　清田侑希　2025/3/28 変更点：↑の機能を削除する*/
void migi()
{
  //Serial.println("turnRight");
  #if DEBUGMODE
    Serial.println(".----migi() Started----.");
  #endif
  // ===== 回転前の準備 =====
  getYawPitchRoll();
  MPU.resetYaw(); // ★ 相対角の基準を 0° に
  delay(50);
  const float TARGET_YAW = 85.0;// 右に90度//@@@tyousei@@@
  sel7();
  sel8();
  
  // ===== 右回転 =====
  while (MPU.getYaw360() < TARGET_YAW || MPU.getYaw360() > 345) {
    drive.turnRight(440);//@@@tyousei@@@
    delay(100);//@@@ // センサ更新
    MPU.update();
    #if DEBUGMODE
      Serial.print("yaw: ");Serial.print(MPU.getYaw360());Serial.println(" ----by migi()");
    #endif
      delay(50);//@@@
  } 

  clearCams();
  delay(2000);
  sel7();
  sel8();

  // ===== 停止 =====
  delay(200);//@@@
  #if DEBUGMODE
    Serial.println("`----migi() Finished----`");
  #endif
  }

/*******************************************************************************************/
/* 左回転                                                                              
/*処理：MPU6050で取得したデータをもとに90度左回転するまでモーターを回し続ける
/*変更点：ギア搭載による回転方向の反転と適切なdelayの実装
/*更新者：清田侑希　2025/1/25
/*　清田侑希　2025/3/12 変更点：90度モーターのみで回転し、90度回らなかったら補正を行う
/*　清田侑希　2025/3/28 変更点：↑の機能を削除する
/*******************************************************************************************/
void hidari() {
  #if DEBUGMODE
    Serial.println(".----hidari() Started----.");
  #endif
  //Serial.println("turnLeft");
  // ===== 回転前の準備 =====
  getYawPitchRoll();      // 念のため最新値に
  MPU.resetYaw();        // ★ 相対角の基準を 0° に
  delay(50);
  const float TARGET_YAW = 275.0;   // 左に90度 //@@@tyousei@@@
  sel7();
  sel8();
  // ===== 左回転 =====
  while (MPU.getYaw360() > TARGET_YAW || MPU.getYaw360() < 15) {
    drive.turnLeft(440); //@@@tyousei@@@
    delay(100);//@@@
    // センサ更新
    MPU.update();
    // デバッグ用（必要なら）
    #if DEBUGMODE
      Serial.print("yaw = ");Serial.print(MPU.getYaw360());Serial.println(" ----by hidari()");
    #endif
    delay(50);//@@@
  }
    clearCams();
    delay(2000);
    sel7();
    sel8();
  // ===== 停止 =====
  delay(200);//@@@
  #if DEBUGMODE
    Serial.println("`----hidari() Finished----`");
  #endif
}

//これらに代わる関数spin()を製作しましたー2026/01/25 by.阿部実裕ー令和六年度入学
#endif

/*******************************************************************************************/
/* 直進                                                                              
/*処理：モーターを回しながら直進この時カラーセンサーとロードセル、カメラの割り込みと坂の検知が入る
/*
/*更新者：清田侑希　2025/1/26
/*清田侑希　2025/3/27 変更点：tofセンサーの値を元にして壁と機体の角度のズレを計算し壁と常に平行になるように補正する
/*清田侑希　2025/3/30　変更点：tofセンサーの値を元にしてタイルの中心とのズレを計算し、常に左右方向でタイルの中心にいるように補正するようにする
/*阿部実裕　2025/01/25 変更点：デバックモード実装
/*******************************************************************************************/
void susumu_heitan() {
  #if DEBUGMODE
    Serial.println(".----susumu_heitan() Started----.");
  #endif
  s1_reset();
  /* ===== 固定パラメータ ===== */
  const int BIAS_PWR  = 60;//@@@tyousei@@@
  const int BIAS_TIME = 80;//@@@
  const int FORWARD_PWR  = 303;//@@@
  const int FORWARD_TIME = 90;//@@@

  /* ===== 距離補正パラメータ ===== */
  const int TOF_DIFF_TH   = 15;   // 左右差がこれ以上で補正//@@@
  const int MAX_CORRECT   = 5;    // 最大補正角（deg）//@@@
  const int CORRECT_PWR  = 70;//@@@
  const int CORRECT_DELAY = 20;//@@@

  count2 = 0;
  /* ---------- 姿勢補正（MPU・絶対角） ---------- */
  if (Status == 3) {
    #if DEBUGMODE
      Serial.println("<----Status is 3 in susumu_heitan()---->");
    #endif
    delay(80);
  }

  /* ---------- 距離による角度補正（実験用・重要） ---------- */
  if (now_wall.rightW == true) {
    #if DEBUGMODE
      Serial.println("<----right_wall is true in susumu_heiatan()---->");
    #endif
    int diff = receivedData[4] - receivedData[5];  // 左右差
    #if DEBUGMODE
      Serial.print("ToF diff: ");Serial.print(diff);Serial.println(" ----by susumu_heitan()");
    #endif
    if (abs(diff) >= TOF_DIFF_TH) {
      // 差を角度に変換（超簡易・安全版）
      int correct_deg = abs(diff) / 5;   // ← 実機で調整OK//@@@tyousei@@@
      correct_deg = constrain(correct_deg, 1, MAX_CORRECT);
      for (int i = 0; i < correct_deg; i++) {
        if (diff > 0) {
          // 左が遠い → 左向き → 右に戻す
          drive.turnRight(CORRECT_PWR);
        } else {
          drive.turnLeft(CORRECT_PWR);
        }
        delay(CORRECT_DELAY);
      }
      drive.stop();
      delay(150);
    }
  }

  /* ---------- 初動バイアス ---------- */
  #if DEBUGMODE
    Serial.println("<----Initial Bias by susumu_heitan()---->");
  #endif
  drive.forward(BIAS_PWR);
  delay(BIAS_TIME);
  
  delay(50);

  /* ---------- 本前進（1タイル） ---------- */
  #if DEBUGMODE
    Serial.println("<----Move One Tile Forward by susumu_heitan()---->");
  #endif
  while (count2 < susumu_kaisuu) {
    drive.forward(FORWARD_PWR);
    for (int t = 0; t < FORWARD_TIME; t += 1) {
      s1();
      sel7();
      sel8();
      delay(1);
      if(BlackTile) break;
    }
    if(BlackTile) break;
    Serial.println(count2);
    count2++;
  }
  drive.stop();
  delay(100);

  /* ---------- 坂判定（既存） ---------- */
  tiziki_2();
  delay(50);
  if (katamuki_true < -10) {//@@@tyousei@@@
    while (katamuki_true < -10) {//@@@
      drive.forward(400);
      delay(100);
      tiziki_2();
    }
  } 
  else if (katamuki_true > 10) {//@@@
    while (katamuki_true > 10) {//@@@
      drive.forward(400);
      delay(100);
      tiziki_2();
    }
  }

  /* ---------- タイル抜け ---------- */
  drive.forward(400);
  delay(300);
  drive.stop();

  /* ---------- 青タイル ---------- */
  if (blue_count == true) {
    #if DEBUGMODE
      Serial.println("<----Blue Tile Delay---->");
    #endif
    delay(5500);
  }

  /* ---------- 後処理 ---------- */
  count2 = 0;
  bump_giveup_count = 0;
  Status = 0;
  blue_count = false;
  drive.stop();
  delay(200);
  #if DEBUGMODE
    Serial.println("`----susumu_heitan() Finished----`");
  #endif
}

