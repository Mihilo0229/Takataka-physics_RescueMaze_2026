/*
void makeMaze(int maxX, int maxY, uint8_t maps[5][5]){
    for(int i = 0; i < maxX; i++){
        for(int j = 0; j < maxY; j++){
            maps[i][j] = 0b1111;
        }
    }

    bool visited[5][5] = {};
    
    carve(0,0,maxX,maxY,maps,visited);
}
*/

void showMap(int x, int y, uint8_t wallmap[maxX][maxY], NodeD here){

  for(int i = y-1; i >= 0; i--){
    for(int j = 0; j < x; j++){
      if(wallmap[j][i] & wallD.N){
        Serial.print("@@");
        Serial.print("@@");
      }
      else{
        Serial.print("@@");
        Serial.print("  ");
      }
      
    }
      

    Serial.println("@@");
    
    for(int j = 0; j < x; j++){
      if(wallmap[j][i] & wallD.W){
        Serial.print("@@");
      }
      else{
        Serial.print("  ");
      }

      if(here.x == j && here.y == i){
        switch(here.dir){
          case North:
            Serial.print("^^");
            break;
          case East:
            Serial.print(">>");
            break;
          case South:
            Serial.print("vv");
            break;
          case West:
            Serial.print("<<");
            break;
        }
      }
      else Serial.print("  ");
      
    }
      
    
    if(wallmap[x-1][i] & wallD.E) Serial.println("@@");
    else Serial.println("  ");
  }
  for(int j = 0; j < x; j++){
    if(wallmap[j][0] & wallD.S){
      Serial.print("@@");
      Serial.print("@@");
    }
    else{
      Serial.print("@@");
      Serial.print("  ");
    }
  }
  Serial.println("@@");

}

void showCostMap(int x, int y, uint8_t wallmap[maxX][maxY], int cost[maxX][maxY]){

  for(int i = y-1; i >= 0; i--){
    for(int j = 0; j < x; j++){
      if(wallmap[j][i] & wallD.N){
        Serial.print("##");
        Serial.print("##");
      }
      else{
        Serial.print("##");
        Serial.print("  ");
      }
      
    }
      

    Serial.println("##");
    
    for(int j = 0; j < x; j++){
      if(wallmap[j][i] & wallD.W){
        Serial.print("##");
      }
      else{
        Serial.print("  ");
      }

      if(cost[j][i] < 10){
        Serial.print("0"); Serial.print(cost[j][i]);
      }
      else{
        Serial.print(cost[j][i]);
      }
    }
      
    
    if(wallmap[x-1][i] & wallD.E) Serial.println("##");
    else Serial.println("  ");
  }
  for(int j = 0; j < x; j++){
    if(wallmap[j][0] & wallD.S){
      Serial.print("##");
      Serial.print("##");
    }
    else{
      Serial.print("##");
      Serial.print("  ");
    }
  }
  Serial.println("##");

}

void DebugCommands(){
if (Serial.available() > 0) {
    char cmd = Serial.read();

    if (cmd == '\n' || cmd == '\r') {
        pcLine.trim();

        // ★ 空行は無視（超重要）
        if (pcLine.length() == 0) {
            pcLine = "";
            return;
        }

        if (pcLine == "/dbg com test") {
            Serial.println("success");
        }
        else if (pcLine == "/dbg s3 test") {
            Serial.println("[PC] F command received");

            byte data[6];
            bool ok = tofUART.request(0x90, data, 150);

            if (!ok) {
                Serial.println("[MyUARTs] timeout or error");
            } else {
                Serial.print("[MyUARTs] recv: ");
                bool success = true;
                for (int i = 0; i < 6; i++) {
                    Serial.print(data[i]);
                    if (i < 5) Serial.print(",");
                    if (data[i] != i + 1) success = false;
                }
                Serial.println();

                if (success) Serial.println("success");
                else Serial.println("data mismatch");
            }
        }
        else if (pcLine == "/dbg s3 run") {
            Serial.println("[PC] F command received");

            byte data[6];
            bool ok = tofUART.request(0x01, data, 150);

            if (!ok) {
                Serial.println("[MyUARTs] timeout or error");
            } else {
                Serial.print("[MyUARTs] recv: ");
                bool success = true;
                for (int i = 0; i < 6; i++) {
                    Serial.print(data[i]);
                    if (i < 5) Serial.print(",");
                    if (data[i] != i + 1) success = false;
                }
                Serial.println();

                if (success) Serial.println("success");
                else Serial.println("data mismatch");
            }
        }
        else if (pcLine == "/dbg s3 adv") {
            Serial.println("[PC] command received");
            get_tof_data();
            Serial.print("r="); Serial.println(now_wall.rightW);
            Serial.print("f="); Serial.println(now_wall.forwardW);
            Serial.print("l="); Serial.println(now_wall.leftW);
            Serial.println("end running");
        }
        else if (pcLine == "/dbg s1 run") {
            Serial.println("[PC] command received");
            s1_reset();
            for(int i = 0;i<6;i++){
              s1();
              Serial.println("running...");
              delay(1000);
            }
            Serial.println("end running");
        }
        else if (pcLine == "/dbg sel8 run") {
            Serial.println("[PC] command received");
            for(int i = 0;i<6;i++){
              sel7();
              sel8();
              Serial.println("running...");
              delay(1000);
            }
            Serial.println("end running");
        }
        else if (pcLine == "/dbg mpu run") {
            Serial.println("[PC] command received");
            for(int i = 0;i<6;i++){
              Serial.println("before update");
              MPU.update();
              Serial.println("after update");
              Serial.print("yaw=");
              Serial.print(MPU.getYaw360());
              Serial.print(" pitch=");
              Serial.print(MPU.getPitch());
              Serial.print(" roll=");
              Serial.println(MPU.getRoll());
              delay(1000);
            }
            Serial.println("end running");
        }
        else if (pcLine == "/dbg num show") {
            Serial.println("[PC] command received");
            Serial.print("[PC] test =");
            Serial.println(test);
            Serial.println(blue_count);
        }
        else if (pcLine == "/dbg num reset") {
            Serial.println("[PC] command received");
            test = 0;
            if(test == 0){
              Serial.println("success");
            }
        }
        else if (pcLine == "/dbg go forward") {
            Serial.println("[PC] command received");
            susumu_heitan();
        }
        else if (pcLine == "/dbg go left") {
            Serial.println("[PC] command received");
            hidari();
        }
        else if (pcLine == "/dbg go right") {
            Serial.println("[PC] command received");
            migi();
        }
        else if (pcLine == "/dbg sv1 run") {
            Serial.println("[PC] command received");
            servo_res();
        }
        else if (pcLine == "/dbg sv2 run") {
            Serial.println("[PC] command received");
            servo_res2();
        }
        else if (pcLine == "/set sv1 run") {
            Serial.println("[PC] command received");
            motor_servo(100,100);
        }
        else if (pcLine == "/set sv2 run") {
            Serial.println("[PC] command received");
            motor_servo2(0,1000);
            Serial.println("end running");
        }
        else if (pcLine == "/set sv2 run") {
            Serial.println("[PC] command received");
            motor_servo2(0,1000);
            Serial.println("end running");
        }
        else if (pcLine == "/show map") {
            Serial.println("[PC] command received");
            showMap(maxX,maxY,Maps,now);
            Serial.println("end running");
        }
        else {
            Serial.print("Unknown cmd: ");
            Serial.println(pcLine);
        }

        pcLine = "";
    }
    else {
        pcLine += cmd;
    }
}
}
