
/*******************************************************************************************/
/* NeoPixelのいろいろな動作関数                                                                            
/*処理：Neopixelを前後左右、赤黄緑に光らせる
/*更新者：清田侑希 2025/3/25
/*更新者:阿部実裕 202/01/25 変更点:デバックモードの実装
/*******************************************************************************************/

void NeoPixels_On(uint8_t r, uint8_t g, uint8_t b) {
  #if DEBUGMODE
    Serial.println(".----NeoPixels_On() Started----.");
  #endif
  pixel1.clear();
  pixel2.clear();
  pixel3.clear();

  pixel1.fill(pixel1.Color(r, g, b));
  pixel2.fill(pixel2.Color(r, g, b));
  pixel3.fill(pixel3.Color(r, g, b));

  pixel1.show();
  pixel2.show();
  pixel3.show();
  
  #if DEBUGMODE
    Serial.println("`----NeoPixels_On() Finished----`");
  #endif
}
void NeoPixels_Off() {
  #if DEBUGMODE
    Serial.println(".----NeoPixels_Off() Started----.");
  #endif
  pixel1.clear();
  pixel2.clear();
  pixel3.clear();

  pixel1.show();
  pixel2.show();
  pixel3.show();
  
  #if DEBUGMODE
    Serial.println("`----NeoPixels_off() Finished----`");
  #endif
}

void NeoPixel1_On(uint8_t r, uint8_t g, uint8_t b) {
  #if DEBUGMODE
    Serial.println(".----NeoPixel1_On() Started----.");
  #endif
  pixel1.clear();
  pixel1.fill(pixel1.Color(r, g, b));
  pixel1.show();
  #if DEBUGMODE
    Serial.println("`----NeoPixel1_On() Finished----`");
  #endif
}
void NeoPixel1_Off() {
  #if DEBUGMODE
    Serial.println(".----NeoPixel1_Off() Started----.");
  #endif
  pixel1.clear();
  pixel1.show();
  #if DEBUGMODE
    Serial.println("`----NeoPixel1_off() Finished----`");
  #endif
}


/*******************************************************************************************/
/* Servo_rescue                                                                              
/*処理：サーボモーターによるレスキューキットの排出
/*
/*更新者：清田侑希 2025/3/26
/*更新者：阿部実裕ー令和六年度入学 2026/01/25 デバックモード実装
/*******************************************************************************************/
void motor_servo(int motor_speed, int seconds) {
  #if DEBUGMODE
    Serial.print(".----motor_servo() Started in motor_speed: ");Serial.print(motor_speed);Serial.print(" seconds: ");Serial.println(seconds);Serial.println(" ----.");
  #endif
  int pulse_width = 1500-motor_speed*8;//@@@tyousei@@@
  int starttime = millis();
  while(true) {
    if (millis()-starttime > seconds) break;
      digitalWrite(SERVO_PIN, HIGH);
      delayMicroseconds(pulse_width);
      digitalWrite(SERVO_PIN, LOW);
      delay(20);    
  }
  #if DEBUGMODE
    Serial.println("`----motor_servo() Finished----`");
  #endif
}

void motor_servo2(int motor_speed, int seconds) {
  #if DEBUGMODE
    Serial.println(".----motor_servo2() Started----.");
  #endif
  int pulse_width = 1400-motor_speed*8;//@@@
  int starttime = millis();
  while(true) {
    if (millis()-starttime > seconds) break;
      digitalWrite(SERVO_PIN2, HIGH);
      delayMicroseconds(pulse_width);
      digitalWrite(SERVO_PIN2, LOW);
      delay(20);    
  }
  #if DEBUGMODE
    Serial.println("`----motor_servo2() Finished----`");
  #endif
}

void servo_res(){
  #if DEBUGMODE
    Serial.println(".----servo_res() Started----.");
  #endif
  motor_servo(130,220);//@@@tyousei@@@
  motor_servo(0,1000);//@@@
  motor_servo(-135,210);//@@@
  motor_servo(0,1000);//@@@
  delay(150);
  servo1_kit--;
  #if DEBUGMODE
    Serial.println("`----servo_res() Finished----`");
  #endif
}

void servo_res2(){//@@@
  #if DEBUGMODE
    Serial.println(".----servo_res2() Started----.");
  #endif
  motor_servo2(-120,200);
  motor_servo2(0,1000);
  motor_servo2(130,200);
  motor_servo2(0,1000);
  delay(150);
  servo2_kit--;
  #if DEBUGMODE
    Serial.println("`----servo_res2() Finished----`");
  #endif
}


/*******************************************************************************************/
/* 座標などのデータ送信                                                                             
/*処理：Serial1を用いて帰還しているかどうか、右、前、左の重み、X,Y座標、方向のデータをSSD1306に送信する
/*
/*更新者：清田侑希　2025/1/30
/*更新者：阿部実裕　2026/01/26 デバックモード実装
/*******************************************************************************************/

void send_display(){
  #if DEBUGMODE
    Serial.println(".----send_display() Started----.");
  #endif
  // 各センサーの距離を取得し壁の有無を判定
  byte data_for_send[7];
  data_for_send[0] = (start_Gohome) ? 0x01 : 0x00;
  data_for_send[1] = (now_wall.rightW);
  data_for_send[2] = (now_wall.leftW);
  data_for_send[3] = (now_wall.forwardW);
  data_for_send[4] = (now.x);
  data_for_send[5] = (now.y);
  data_for_send[6] = (now.dir);

  /*data_for_send[0] = (start_Gohome) ? 0x01 : 0x00;
  data_for_send[1] = (kabe_zahyou[x][y]);
  data_for_send[2] = (x);
  data_for_send[3] = (y);
  data_for_send[4] = (Direction);*/

  display.clearDisplay();
  display.setCursor(0, 0);
  display.println("Go home: " + String(data_for_send[0]));
  display.println("Right: " + String(data_for_send[1]));
  display.println("Left: " + String(data_for_send[2]));
  display.println("Front: " + String(data_for_send[3]));
  display.print("now.x: " + String(data_for_send[4]) + " now.y: " + String(data_for_send[5]));
  display.println(" now.dir: " + String(data_for_send[6]));
  display.display();

  #if DEBUGMODE
    Serial.print("Sent data: ");//デバック用にシリアルモニタに送信
    for (int i = 0; i < 7; i++) {
      Serial.print(data_for_send[i], BIN);
      if (i < 6) Serial.print(", ");
    }
    Serial.println(" ----by send_display()");
  #endif
  delay(200); // 必要に応じて調整
  #if DEBUGMODE
    Serial.println("`----send_display() Finished----`");
  #endif
}
