
/*******************************************************************************************/
/* get_victim_data                                                                              
/*処理：OpenMVによって被災者の発見
/*
/*更新者：清田侑希 2025/2/23
/*清田侑希 2025/3/26 変更点：被災者を発見したときにLEDを点灯させる
/* 清田侑希 2025/3/28 変更点：被災者を発見したときにサーボモーターを動かす
/*阿部実裕 2026/01/25 変更点:デバックモード実装
/*******************************************************************************************/
//右側のカメラ
void sel7() {
  #if DEBUGMODE
    Serial.println(".----sel7() Started----.");
  #endif

  // すでに処理済みなら何もしない
  if (VictimisAlready[now.x][now.y]){
    #if DEBUGMODE
      Serial.println("!----sel7() Stopped deu to Already Processed----!");
    #endif
    return;
  }

  // データが無ければ何もしない
  if (!cam7.hasEvent()){
    #if DEBUGMODE
      Serial.println("!----sel7() Stopped deu to No Data----!");
    #endif
    return;
  }

  // ===== ヘッダ探索 =====
  byte header = cam7.readEvent();
  if (header != 0xAA) {
    // 同期ずれ → 破棄
    #if DEBUGMODE
      Serial.println("!----sel7() Stopped deu to Out of Sync----!");
    #endif
    return;
  }

  // ===== 残り2バイト待ち =====
  if (Serial7.available() < 2) {
    // フレーム未完成
    #if DEBUGMODE
      Serial.println("!----sel7() Stopped deu to Unfinished Frame----!");
    #endif
    return;
  }

  byte receivedData  = cam7.readEvent();
  byte check = cam7.readEvent();

  // ===== チェックサム検証 =====
  if ((receivedData ^ 0xFF) != check) {
    // 壊れたフレーム
    #if DEBUGMODE
      Serial.println("!----sel7() Stopped deu to Broken Frame----!");
    #endif
    return;
  }

  // ===== ここから先は「正しい通信」 =====
  VictimisAlready[now.x][now.y] = true;  
  #if DEBUGMODE
    Serial.println("<----sel7() Proceeded to Correct Communication without any Error---->");
  #endif
  switch (receivedData) {

    /* ======================
       H victim
       ====================== */
    case 1:
      #if DEBUGMODE
        Serial.println("<----H_victim was Located on the Right-hand side by sel7()---->");
      #endif
      for (int i = 0; i < 5; i++) {
        NeoPixels_On(255, 0, 0);
        delay(650);
        NeoPixels_Off();
        delay(650);
      }

      if (servo1_kit >= 2) {
        servo_res(); delay(650);
        servo_res(); delay(650);

      } else if (servo1_kit == 1 && servo2_kit >= 1) {

        servo_res(); delay(500);

        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@tyousei@@@
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@

        servo_res2(); delay(500);

        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@

      } else if (servo2_kit >= 2) {

        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@

        servo_res2(); delay(500);
        servo_res2(); delay(500);

        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@

      } else if (servo1_kit == 1) {

        servo_res(); delay(500);

      } else if (servo2_kit == 1) {

        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@

        servo_res2(); delay(500);

        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@
      }
      break;

    /* ======================
       S victim
       ====================== */
    case 2:
      #if DEBUGMODE
        Serial.println("<----S_victim was Located on the Right-hand side by sel7()---->");
      #endif
      for (int i = 0; i < 5; i++) {
        NeoPixels_On(255, 200, 0);
        delay(650);
        NeoPixels_Off();
        delay(650);
      }

      if (servo1_kit >= 1) {

        servo_res(); delay(500);

      } else if (servo2_kit >= 1) {

        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@

        servo_res2(); delay(500);

        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@
      }
      break;

    /* ======================
       Red victim
       ====================== */
    case 4:
      #if DEBUGMODE
        Serial.println("<----red_victim was Located on the Right-hand side by sel7()---->");
      #endif
      for (int i = 0; i < 3; i++) {
        NeoPixels_On(255,0,0);
        delay(1000);
        NeoPixels_Off();
        
        delay(1000);
      }

      if (servo1_kit >= 2) {

        servo_res(); delay(500);
        servo_res(); delay(500);

      } else if (servo1_kit == 1 && servo2_kit >= 1) {

        servo_res(); delay(500);

        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@

        servo_res2(); delay(500);

        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@

      } else if (servo2_kit >= 2) {

        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@

        servo_res2(); delay(500);
        servo_res2(); delay(500);

        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@

      } else if (servo1_kit == 1) {

        servo_res(); delay(500);

      } else if (servo2_kit == 1) {

        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@

        servo_res2(); delay(500);

        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@
      }
      break;

    /* ======================
       Yellow victim
       ====================== */
    case 5:
      #if DEBUGMODE
        Serial.println("<----yellow_victim was Located on the Right-hand side by sel7()---->");
      #endif
      for (int i = 0; i < 3; i++) {
        NeoPixels_On(255,200,0);
        delay(1000);
        NeoPixels_Off();
        
        delay(1000);
      }

      if (servo1_kit >= 1) {

        servo_res(); delay(500);

      } else if (servo2_kit >= 1) {

        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@

        servo_res2(); delay(500);

        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);//@@@
      }
      break;

    default:
      #if DEBUGMODE
        Serial.print("<----Unknown cam7 event: ");
        Serial.print(receivedData);
        Serial.println(" by sel7()---->");
      #endif
      break;
  }

  drive.stop();
  #if DEBUGMODE
    Serial.println("`----sel7() Finished----`");
  #endif
}

/*******************************************************************************************/
/* get_victim_data2                                                                              
/*処理：OpenMVによって被災者を発見する
/*
/*更新者：清田侑希　2025/2/23
/*清田侑希　2025/3/26 変更点：被災者を発見したときにLEDを点灯させる
/* 清田侑希　2025/3/28 変更点：被災者を発見したときにサーボモーターを動かす
/* 阿部実裕　2026/01/25 変更点:デバックモード実装
/*******************************************************************************************/
//左側のカメラ

void sel8() {//@@@tyousei@@@
  #if DEBUGMODE
    Serial.println(".----sel8() Started----.");
  #endif
  // すでに処理済みなら何もしない
  if (VictimisAlready[now.x][now.y]){
    #if DEBUGMODE
      Serial.println("!----sel8() Stopped deu to Already Processed----!");
    #endif
    return;
  }

  // データが無ければ何もしない
  if (!cam1.hasEvent()){
    #if DEBUGMODE
      Serial.println("!----sel8() Stopped deu to No Data----!");
    #endif
    return;
  }

  // ===== ヘッダ探索 =====
  byte header = cam1.readEvent();
  if (header != 0xAA) {
    // 同期ずれ → 破棄
    #if DEBUGMODE
      Serial.println("!----sel8() Stopped deu to Out of Sync----!");
    #endif
    return;
  }

  // ===== 残り2バイト待ち =====
  if (Serial1.available() < 2) {
    // フレーム未完成
    #if DEBUGMODE
      Serial.println("!----sel8()  Stopped deu to Unfinished Frame----!");
    #endif
    return;
  }

  byte receivedData  = cam1.readEvent();
  byte check = cam1.readEvent();

  // ===== チェックサム検証 =====
  if ((receivedData ^ 0xFF) != check) {
    // 壊れたフレーム
    #if DEBUGMODE
      Serial.println("!----sel8() Stopped deu to Broken Frame----!");
    #endif
    return;
  }

  // ===== ここから先は「正しい通信」 =====
  VictimisAlready[now.x][now.y] = true;
  #if DEBUGMODE
    Serial.println("<----sel8() Proceeded to Correct Communication without any Error---->");
  #endif
  
  switch (receivedData) {

    /* =========================
       1 : H victim
       ========================= */
    case 1:
      #if DEBUGMODE
        Serial.println("<----H_victim was Located on the Left-hand side by sel8()---->");
      #endif
      for (int i = 0; i < 5; i++) {
        NeoPixels_On(255,0,0);
        delay(650);
        NeoPixels_Off();
        
        delay(650);
      }

      if (servo2_kit >= 2) {
        servo_res2(); delay(650);
        servo_res2(); delay(650);
      }
      else if (servo2_kit == 1 && servo1_kit >= 1) {
        servo_res2(); delay(500);
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
        servo_res(); delay(500);
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
      }
      else if (servo1_kit >= 2) {
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
        servo_res(); delay(500);
        servo_res(); delay(500);
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
      }
      else if (servo2_kit == 1) {
        servo_res2(); delay(500);
      }
      else if (servo1_kit == 1) {
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
        servo_res(); delay(500);
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
      }
      break;

    /* =========================
       2 : S victim
       ========================= */
    case 2:
      #if DEBUGMODE
        Serial.println("<----S_victim was Located on the Left-hand side by sel8()---->");
      #endif
      for (int i = 0; i < 5; i++) {
        NeoPixels_On(255,200,0);
        delay(650);
        NeoPixels_Off();
        
        delay(650);
      }

      if (servo2_kit >= 1) {
        servo_res2(); delay(500);
      }
      else if (servo1_kit >= 1) {
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
        servo_res(); delay(500);
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
      }
      break;

    /* =========================
       4 : red victim
       ========================= */
    case 4:
      #if DEBUGMODE
        Serial.println("<----red_victim was Located on the Left-hand side by sel8()---->");
      #endif
      for (int i = 0; i < 3; i++) {
        NeoPixels_On(255,0,0);
        delay(1000);
        NeoPixels_Off();
        
        delay(1000);
      }

      if (servo2_kit >= 2) {
        servo_res2(); delay(500);
        servo_res2(); delay(500);
      }
      else if (servo2_kit == 1 && servo1_kit >= 1) {
        servo_res2(); delay(500);
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
        servo_res(); delay(500);
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
      }
      else if (servo1_kit >= 2) {
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
        servo_res(); delay(500);
        servo_res(); delay(500);
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
      }
      else if (servo2_kit == 1) {
        servo_res2(); delay(500);
      }
      else if (servo1_kit == 1) {
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
        servo_res(); delay(500);
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
      }
      break;

    /* =========================
       5 : yellow victim
       ========================= */
    case 5:
      #if DEBUGMODE
        Serial.println("<----yellow_victim was Located on the Left-hand side by sel8()---->");
      #endif
      for (int i = 0; i < 3; i++) {
        NeoPixels_On(255,200,0);
        delay(1000);
        NeoPixels_Off();
        
        delay(1000);
      }

      if (servo2_kit >= 1) {
        servo_res2(); delay(500);
      }
      else if (servo1_kit >= 1) {
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
        servo_res(); delay(500);
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
        drive.turnRight(1000); delay(1700); drive.stop(); delay(300);
      }
      break;

    default:
      // 3, 6, その他は無視
      #if DEBUGMODE
        Serial.println("<----3, 6, or Other was Located by sel8()---->");
      #endif
      break;
  }
  #if DEBUGMODE
    Serial.println("`----sel8() Finished----`");
  #endif
}

void clearCams() {
  #if DEBUGMODE
    Serial.println(".----clearCams() Started----.");
  #endif
  while (Serial7.available() > 0) {
    Serial7.read();
  }
  while (Serial1.available() > 0) {
    Serial1.read();
  }
  #if DEBUGMODE
    Serial.println("`----clearCams() Finished----`");
  #endif
}
