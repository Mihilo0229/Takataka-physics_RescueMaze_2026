#define DEBUGMODE 1//on->1 off->0
//Trueでデバックモード,随時情報をSerial.printするようになる。

#include <stdio.h>
#include <cstdint>
#include <Arduino.h>
#include <time.h>
#include <cstdint>
#include <SCServo.h> //SCServoを使うと宣言]
#include <SoftwareSerial.h> //SoftwareSerial(複数機器とシリアル通信)を使うと宣言
#include <Adafruit_NeoPixel.h>
#include <queue>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include "MyBasicDrive.h"
#include "MyUARTs_read.h"
#include "MyYPRs.h"

#define CMD_TOF 0x01
#define EVT_READY 7//スタート前のバンパの準備確認用ID

#define right 2//Algo
#define forwerd 3
#define left 1
#define back 0

#define North 0//Algo
#define East 1
#define South 2
#define West 3
#define Err 4

/*.........NeoPixelの変数の定義........................*/
#define PIN1       2    // データ信号用のピン
#define PIN2       3    // データ信号用のピン
#define PIN3       4    // データ信号用のピン
#define BRIGHTNESS 100   // LEDの明るさを設定 (0～255)


MyYPRs MPU;   // ← これが mpu + dmp + ypr の代役
MyBasicDrive drive;
MyUARTs_read colorUART,tofUART,cam7,cam1;
SMS_STS sms_sts;
SoftwareSerial SoftwareSerial(36,37);
Adafruit_NeoPixel pixel1(1, PIN1, NEO_GRB + NEO_KHZ800); //8個のNeoPixelがSeeedのデジタルピン27に接続され、GRB順の800kHzのデータ伝送速度で動作
Adafruit_NeoPixel pixel2(1, PIN2, NEO_GRB + NEO_KHZ800); //8個のNeoPixelがSeeedのデジタルピン27に接続され、GRB順の800kHzのデータ伝送速度で動作
Adafruit_NeoPixel pixel3(1, PIN3, NEO_GRB + NEO_KHZ800); //8個のNeoPixelがSeeedのデジタルピン27に接続され、GRB順の800kHzのデータ伝送速度で動作


/*.....tof受信用の変数.......................................*/
byte receivedData[6];  // 受信データ格納用
byte tof_buf[6];

/*MPU変数*/
// MPU control/status vars
double pitch;
double roll;
double yaw;

/*..................レスキューキット排出用のサーボモーターの変数の定義............*/
const int SERVO_PIN = 33; //servo2 36
const int SERVO_PIN2 = 23;
int servo1_kit = 5; //レスキューキットの残数//@@@tyousei@@@
int servo2_kit = 5; //上に同じ//@@@

byte ID[4]; //IDはそれぞれのモーターのID
s16 Position[4]; //Positionはモーターが回る角度(右一回転＝4095)
u16 Speed[4]; 
byte ACC[4]; 


/*..........................................................*/
/*センサー類変数*/
int susumu_kaisuu= 40;//@@@tyousei@@@
double katamuki; //tiziki2()でのrollの代入
int katamuki_true; //tiziki2()でrollを整数化したあとの変数
int count2 = 0;//進んだ回数＿40回でわかれている
int bump_giveup_count = 0; //障害物に当たった時あきらめる変数

bool VictimisAlready[90][90];
int8_t BlackTile =false;
int8_t blue_count =false;
bool Slope = false;//sloopがあるかどうか
bool Gap = false;

/*monitor*/
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire2, OLED_RESET);



/*デバッグ用*/
uint8_t Homecount = 0;
bool BFScount = false;

int isItWall = 225;//@@@tyousei@@@

bool sub_ready = false;
unsigned long lastBlink = 0;
bool ledState = false;

String pcLine = "";
int debug = 0;

long now_seconds;
long firstseconds;
bool start_Gohome = false;

/** 超信地旋回のデフォルト速度
 * @note spin() の第二引数たる速度のデフォルト値
 * @note 推奨 : 440 */
const int DEFAULT_SPIN_SPEED = 440;

uint8_t Status = 0;

bool happenError = false;

const int maxX = 90;//横軸最大値
const int maxY = 90;//縦軸最大値

struct wallDirection{
  uint8_t N = 0b1000;
  uint8_t E = 0b0100;
  uint8_t S = 0b0010;
  uint8_t W = 0b0001;
};

struct NodeD{
  int x;
  int y;
  int dir;
};

struct Wall{
  bool rightW;
  bool forwardW;
  bool leftW;
  int dir;
};

wallDirection wallD;

std::queue<NodeD> Map_Q;
std::queue<int> way_q;

int went[maxX][maxY];

int cost[maxX][maxY];

Wall  walls[maxX][maxY];

uint8_t Maps[maxX][maxY];

NodeD now = {50,50,North};
NodeD checkPoint = {50,50,North};
NodeD start = {50,50,North};

int deb = 0;

Wall now_wall;

#if DEBUGMODE
float test = 0;
#endif


void setup() {/*センサーのセットアップ***********************************************************************************************************/
  Serial.begin(9600);   // デバッグ用
  Serial4.begin(19200); //using_color_load
  colorUART.begin(&Serial4);
  Serial2.begin(1000000);//using_servo_sts3032
  Serial3.begin(9600);  // using_tof
    // ToF UART ライブラリ初期化
  tofUART.begin(&Serial3);
  Serial7.begin(19200);//using_cam1
  Serial1.begin(19200);//using_cam2
  // ===== カメラUARTラッパ初期化 =====
  cam7.begin(&Serial7);
  cam1.begin(&Serial1);
  pinMode(22, INPUT); //スタート用スイッチのpin設定
  pinMode(SERVO_PIN, OUTPUT);//レスキューキット用のサーボモーターのpin設定
  pinMode(SERVO_PIN2, OUTPUT);//上に同じ
  delay(2000);
  /*MPUのセットアップ***********************************************************************************************************/
  Wire.begin();
  Wire.setClock(400000); // 400kHz I2C clock. Comment this line if having compilation difficulties
  if (!MPU.begin()) {
    Serial.println("MyYPRs MPU init failed");
    while (1);
  }
  MPU.resetYaw();

  /*monitor setuup*/
  Wire2.begin();
  Wire2.setClock(400000);

  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(0,0);

  send_display();

  
  /* モーターのセットアップ */
  SoftwareSerial.begin(9600);

  sms_sts.pSerial = &Serial2;   // ← これは正しい
  delay(1000);

  ID[0] = 1; // 右前
  ID[1] = 2; // 左前
  ID[2] = 3; // 右後
  ID[3] = 4; // 左後

  Speed[0] = 6800;
  Speed[1] = 6800;
  Speed[2] = 6800;
  Speed[3] = 6800;
  
  ACC[0] = 50;
  ACC[1] = 50;
  ACC[2] = 50;
  ACC[3] = 50;

  Serial.println("test");

  /* ★ ここが正解 ★ */
  drive.begin(&sms_sts,
            ID,
            Speed,
            ACC);

    /*...........NeoPixelのセットアップ.......*/
    pixel1.begin(); // NeoPixelの初期化
    pixel1.setBrightness(BRIGHTNESS); // 明るさを設定
    pixel2.begin(); // NeoPixelの初期化
    pixel2.setBrightness(BRIGHTNESS); // 明るさを設定
    pixel3.begin(); // NeoPixelの初期化
    pixel3.setBrightness(BRIGHTNESS); // 明るさを設定


  /*スタック・キューのセットアップ***********************************************************************************************************
  init();
  st_init();
  */

  for(int i = 0; i < 90; i++){
    for(int j = 0; j < 90; j++){
      cost[i][j] = 9999;
      VictimisAlready[i][j] = false;
      went[i][j] = 0;
      Maps[i][j] = 0b1111;
    }
  }
  cost[50][50] = 0;
  Map_Q.push({50,50,North});

}

void loop() {
  while (digitalRead(22) == LOW) {
    delay(10);
    if (deb == 100){
      Serial.println("Waiting...@start-button");
      deb = 0;
    }
    deb = deb + 1; 
    // ===== PC → メインマイコン デバッグ通信 =====
    #if DEBUGMODE
      DebugCommands();
    #endif
    // ===== サブマイコン READY イベント監視 =====
    uint8_t evt;
    if (colorUART.readEventFrame(evt)) {
        if (evt == EVT_READY) {
            sub_ready = true;
            Serial.println("SUB MCU READY");
        }
    }

    // ===== NeoPixel 表示 =====
    unsigned long nowtime = millis();

    if(sub_ready == true && debug == 0) {
        // 準備完了：緑点滅（0.5秒周期）
        if (nowtime - lastBlink > 500 && debug < 3) {
            lastBlink = nowtime;
            ledState = !ledState;

            if (ledState) {
                NeoPixels_On(0,0,100);  // 緑
            } else {
                NeoPixels_Off();
                debug++;
            }
            
        }
    }
    if (digitalRead(22) == HIGH) {
        // サブマイコンの残骸データを消す
        while (Serial3.available() > 0) {
            Serial3.read();
        }

        // チェックポイント復帰
        now = checkPoint;
        Status = 0;
        break;
    }

  }

  
    switch (Status)
    {
    case 0://壁情報取得

        get_tof_data();
        break;
    
    case 1:
        RHR_inputWalls(walls[now.x][now.y],now);
        RHR_inputMaps(walls[now.x][now.y],now);

        switch(RHR_whichWay(walls[now.x][now.y],now)){
          case right:
            Status = 4;
            break;
          case forwerd:
            Status = 3;
            break;
          case left:
            Status = 5;
            break;
          case back:
            Status = 6;
            break;
          default:
            Status = 0;
            break;
        }

        now = RHR_nextPosition(now, RHR_whichWay(walls[now.x][now.y],now));
        went[now.x][now.y]++;

        time_t NowTime;
        time(&NowTime);  // 現在の時刻を取得して NowTime に格納
        now_seconds = static_cast<long>(NowTime); 

        //330秒（＝5分半）経ったら幅優先探索を始める
        if(now_seconds - firstseconds >= 360){//@@@tyousei@@@
            Status = 2;//帰還開始
            start_Gohome = true;
        }

        Serial.print("keika jikann :"); Serial.println(now_seconds - firstseconds);//debug
        
        break;
    
    case 2://帰還
        cost[50][50] = 0;
        Map_Q.push(start);

        BFS_makeMap();

        BFS_wayHome(now);

        while(!way_q.empty()){
          switch(way_q.front()){
            case 1:
              hidari();
              now.dir = clearD(now.dir -1);
              break;
            case 2:
              migi();
              now.dir = clearD(now.dir +1);
              break;
            case 3:
              susumu_heitan();
              switch(now.dir){
                case North:
                  now.y++;
                  break;
                case East:
                  now.x++;
                  break;
                case South:
                  now.y--;
                  break;
                case West:
                  now.x--;
                  break;
              }
              TileStatus();
              break;
          }
          way_q.pop();

          if(happenError){
            Status = 0;
            break;
          }
        }

        if(way_q.empty() && !happenError){
          NeoPixels_On(0,0,255);    
          delay(20000);
        }

        break;

    case 3://直進
        susumu_heitan();
        delay(200);//@@@
        TileStatus();
        break;

    case 4://右折
        migi();
        delay(500);//@@@
        susumu_heitan();
        delay(200);//@@@
        TileStatus();
        break;

    case 5://左折
        hidari();
        delay(500);//@@@
        susumu_heitan();
        delay(200);//@@@
        TileStatus();
        break;

    case 6://後進
        hidari();
        delay(500);//@@@
        hidari();
        delay(500);//@@@
        susumu_heitan();
        delay(200);//@@@
        TileStatus();
        break;
    }
    send_display();
}
