
int clearD(int rawD){
  int ans = (rawD % 4 + 4) % 4;
  return ans;
}

int RHR_whichWay(Wall here, NodeD hereD){
  int rwall=0, fwall=0, lwall=0;

  if(here.rightW) rwall = 1;
  if(here.forwardW) fwall = 1;
  if(here.leftW) lwall = 1;
  
  int right_waight, forward_waight, left_waight, back_waight;
  
  right_waight = min(here.rightW * 100 + went[hereD.x][hereD.y] * 5 + 1,100);
  forward_waight = min(here.forwardW * 100 + went[hereD.x][hereD.y] * 5 + 2,100);
  left_waight = min(here.leftW * 100 + went[hereD.x][hereD.y] * 5 + 3,100);
  back_waight = 399 - right_waight - forward_waight - left_waight;

//  Serial.print(right_waight);Serial.print(" - ");
//  Serial.print(forward_waight);Serial.print(" - ");
//  Serial.print(left_waight);Serial.print(" - ");
//  Serial.println(back_waight);

  if (right_waight < min(forward_waight,left_waight)) return right;
  else if (forward_waight < left_waight) return forwerd;
  else if (left_waight < back_waight) return left;
  else return back;
}

NodeD RHR_nextPosition(NodeD here,int next){
  if (here.dir == North){
    if(next == right) return {here.x+1,here.y,clearD(here.dir + 1)};
    else if(next == forwerd) return {here.x,here.y+1,clearD(here.dir + 0)};
    else if(next == left) return {here.x-1,here.y,clearD(here.dir - 1)};
    else if(next == back) return {here.x,here.y-1,clearD(here.dir - 2)};
  }
  else if (here.dir == East){
    if(next == right) return {here.x,here.y-1,clearD(here.dir + 1)};
    else if(next == forwerd) return {here.x+1,here.y,clearD(here.dir + 0)};
    else if(next == left) return {here.x,here.y+1,clearD(here.dir - 1)};
    else if(next == back) return {here.x-1,here.y,clearD(here.dir - 2)};
  }
  else if (here.dir == South){
    if(next == right) return {here.x-1,here.y,clearD(here.dir + 1)};
    else if(next == forwerd) return {here.x,here.y-1,clearD(here.dir + 0)};
    else if(next == left) return {here.x+1,here.y,clearD(here.dir - 1)};
    else if(next == back) return {here.x,here.y+1,clearD(here.dir - 2)};
  }
  else if (here.dir == West){
    if(next == right) return {here.x,here.y+1,clearD(here.dir + 1)};
    else if(next == forwerd) return {here.x-1,here.y,clearD(here.dir + 0)};
    else if(next == left) return {here.x,here.y-1,clearD(here.dir - 1)};
    else if(next == back) return {here.x+1,here.y,clearD(here.dir - 2)};
  }
  return {0,0,North};
}


void RHR_inputWalls(Wall &here, NodeD hereD){

  //koko ni kabe jouhou wo ireru ko-do kaku

  if(now_wall.rightW) here.rightW = true;
  else here.rightW = false;
  if(now_wall.forwardW) here.forwardW = true;
  else here.forwardW = false;
  if(now_wall.leftW) here.leftW = true;
  else here.leftW = false;

  here.dir = hereD.dir;
}

void RHR_inputMaps(Wall here,NodeD hereD){
  uint8_t ans = 0;
  switch(hereD.dir){
    case North:
      if(here.rightW) ans = ans + wallD.E;
      if(here.forwardW) ans = ans + wallD.N;
      if(here.leftW) ans = ans + wallD.W;
      Maps[hereD.x][hereD.y] = ans;
      break;
    case East:
      if(here.rightW) ans = ans + wallD.S;
      if(here.forwardW) ans = ans + wallD.E;
      if(here.leftW) ans = ans + wallD.N;
      Maps[hereD.x][hereD.y] = ans;
      break;
    case South:
      if(here.rightW) ans = ans + wallD.W;
      if(here.forwardW) ans = ans + wallD.S;
      if(here.leftW) ans = ans + wallD.E;
      Maps[hereD.x][hereD.y] = ans;
      break;
    case West:
      if(here.rightW) ans = ans + wallD.N;
      if(here.forwardW) ans = ans + wallD.W;
      if(here.leftW) ans = ans + wallD.S;
      Maps[hereD.x][hereD.y] = ans;
      break;
  }
}


/*******************************************************************************************/
/* タイルの状態                                                                              
/*処理：それぞれの方向について、
/*      黒タイルの場合そのマスの重みを100にする
/*      黒タイルまたは"少しずれている"の信号が送られていたら一マス戻る
/*      坂の信号が送られていたら一マス進む
/*      黒タイルと坂信号の初期化
/*
/*更新者：吉ノ薗2025/01/22
/*更新者：阿部実裕　2026/01/26 デバックモード実装
/*******************************************************************************************/

void TileStatus(){
  #if DEBUGMODE
    Serial.println(".----TileStatus() Started----.");
  #endif
  if(BlackTile){
      went[now.x][now.y] += 100;
  }

  if(Status == 2 && (BlackTile || Gap)){
    happenError = true;
  }

  switch (now.dir){
    case North:
      if(BlackTile || Gap){//黒タイルまたはずれの信号が送られていた場合戻る
        #if DEBUGMODE
          Serial.println("<----North Case BlackTile or Gap in TileStatus()---->");
        #endif
        now.y += -1;
      }
      break;

    case East:
      if(BlackTile || Gap){//黒タイルの信号が送られていた場合戻る
        #if DEBUGMODE
          Serial.println("<----East Case BlackTile or Gap in TileStatus()---->");
        #endif
        now.x += -1;
      }
      break;
    
    case West:
      if(BlackTile || Gap){//黒タイルの信号が送られていた場合戻る
        #if DEBUGMODE
          Serial.println("<----West Case BlackTile or Gap in TileStatus()---->");
        #endif
        now.x += 1;
      }
      break;

    case South:
      if(BlackTile || Gap){//黒タイルの信号が送られていた場合戻る
        #if DEBUGMODE
          Serial.println("<----South Case BlackTile or Gap in TileStatus()---->");
        #endif
        now.y += 1;
      }
      break;
  }
  BlackTile = false;
  Slope = false;
  Gap = false;
  #if DEBUGMODE
    Serial.println("`----TileStatus() Finished----`");
  #endif
}
